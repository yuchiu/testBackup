<?php

$string['checklist'] = 'Lista de Cotejo';
$string['choosechecklist'] = 'Elija Lista de Cotejo';
$string['choosegroup'] = 'Elija grupo';
$string['nochecklist'] = 'Por favor edite este bloque para seleccionar una lista de verificaci&oacute;n para mostrar';
$string['nochecklistplugin'] = 'Necesita instalar la &uacute;ltima versi&oacute;n del plugin de lista de control para este bloque de trabajo';
$string['nousers'] = 'Sin usuarios';

