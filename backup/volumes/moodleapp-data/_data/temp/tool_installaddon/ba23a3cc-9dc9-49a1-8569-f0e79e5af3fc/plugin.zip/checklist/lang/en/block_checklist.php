<?php

$string['checklist'] = 'Checklist';
$string['checklist:addinstance'] = 'Add Checklist block to My Moodle page';
$string['checklist:myaddinstance'] = 'Add new Checklist block';
$string['checklistoverview'] = 'Checklist overview';
$string['choosechecklist'] = 'Choose checklist';
$string['choosegroup'] = 'Default group';
$string['nochecklist'] = 'Please edit this block to select a checklist to display';
$string['nochecklistplugin'] = 'You need to install the latest version of the checklist plugin for this block to work';
$string['notenrolled'] = 'You are not enrolled on any courses';
$string['nousers'] = 'No users';
$string['pluginname'] = 'Checklist';
