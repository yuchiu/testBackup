<?php

$string['checklist'] = 'Liste des t&acirc;ches';
$string['choosechecklist'] = 'Choisir une Liste des t&acirc;ches';
$string['choosegroup'] = 'Choisir un groupe';
$string['nochecklist'] = 'Merci d\'&eacute;diter ce bloc pour s&eacute;lectionner une Liste des t&acirc;ches &agrave; visualiser';
$string['nochecklistplugin'] = 'Vous devez installer la derni&egrave;re version du plugin Liste des t&acirc;ches pour que ce bloc fonctionne';
$string['nousers'] = 'Pas d\'utilisateur';
$string['pluginname'] = 'Liste des t&acirc;ches';
