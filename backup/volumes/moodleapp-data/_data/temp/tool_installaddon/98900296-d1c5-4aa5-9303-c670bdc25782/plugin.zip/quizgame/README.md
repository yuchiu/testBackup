Quizventure
===========

Students procastinating too much? Are they playing games instead of studying? Well now you can motivate them by allowing them to do both at once!

Quizventure is an activity module that loads quiz questions from the course it's added to.
The possible answers come down as space ships and you have to shoot the correct one.

Module Installation
===================

To install, go to the [Quizventure page](https://moodle.org/plugins/view.php?plugin=mod_quizgame) on the plugins DB.

Alternatively, to install from [github](https://github.com/xow/moodle-mod_quizgame) click "Download ZIP" on the right, then extract the contents into mod/quizgame. Login to your moodle site as admin, go to Site Administration>Notifications and follow the prompts

Details and Setup
=================

It only supports multiple choice questions for now (other questions types will be ignored).

Just copy the questions into the courses default category, and add the game to your course.

